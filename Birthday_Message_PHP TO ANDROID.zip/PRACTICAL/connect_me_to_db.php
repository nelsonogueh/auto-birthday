<?php

// connect to the database 
$connect = mysql_connect("localhost","root","");
$db = mysql_select_db('practical' , $connect) or die('Could not connect to database'.mysql_error());
if(!$db){
	echo "Not connected to database";
}
?>