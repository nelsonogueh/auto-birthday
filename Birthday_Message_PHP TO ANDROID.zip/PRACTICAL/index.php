
<?php
include('connect_me_to_db.php');

if(!isset($_GET['number_of_input_to_provide'])){
	?>
	<h2> Enter number of input needed</h2>
	<form action="<?php $_SERVER['PHP_SELF']; ?>" method="get">
	<input type="number" name="number_of_input_to_provide" autofocus />
	<input type="submit" value="Submit" />
	</form>
	
	<a href="get_all_messages_from_db.php"> Get all message from DB</a>
	<?php
}




if(isset($_GET['number_of_input_to_provide'])){
	$howManyInput = mysql_real_escape_string($_GET['number_of_input_to_provide']);
?>

<form method="post" action="message_check.php" >

<?php for($i=0;  $i<$howManyInput; $i++){ ?>
<textarea name="<?php echo $i; ?>" placeholder="message..." ></textarea>  </br >
<input type="hidden" name="totalValueBrought" value="<?php echo $howManyInput; ?>" />
<?php 
} 
?>
<input type="submit" value="Submit" />
</form>


<br />
 <a href="index.php"> go home</a>
<?php 
}
?>