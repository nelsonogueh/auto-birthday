 <?php
 include('connect_me_to_db.php');
		$selectDB = mysql_query("SELECT * FROM birthday_message") or die(mysql_error());
		if($selectDB){
			if(mysql_num_rows($selectDB)>0){
				?>
			db.execSQL("INSERT INTO birthday_message (Message_Type,Message_Body, Online_Unique_Id) VALUES
			<?php
				while($row = mysql_fetch_array($selectDB)){
				?>
				
				('system',"+DatabaseUtils.sqlEscapeString("<?php echo trim($row['Message']); ?>")+", '<?php echo $row['Message_Id']; ?>'),
				
				<?php
				}
			?>
			");
			<?php				
				
			}
			else{
				echo "No values";
			
			}
		}
		else{
			echo "Query did not run";
		}
		 
?>
