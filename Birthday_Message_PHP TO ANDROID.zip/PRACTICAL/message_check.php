 <?php
 include('connect_me_to_db.php');
 $howManyInput = mysql_real_escape_string(trim($_POST['totalValueBrought']));
 
 // echo $howManyInput;
 
 for($i=0;  $i<$howManyInput; $i++){ 
		$messagesBrought = mysql_real_escape_string($_POST["".$i.""]);
		// echo $messagesBrought;
		$insertDB = mysql_query("INSERT INTO birthday_message(Message) VALUES('$messagesBrought')");
		
} 

if($insertDB){
			header("location: index.php");
		}
		else{
			echo "Message was not submitted to db";
		}
 ?>
 <br />
 <a href="index.php"> go home</a>