-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2017 at 11:52 PM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `practical`
--

-- --------------------------------------------------------

--
-- Table structure for table `birthday_message`
--

CREATE TABLE `birthday_message` (
  `Message_Id` int(11) NOT NULL,
  `Message` longtext,
  `Date_Added` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `birthday_message`
--

INSERT INTO `birthday_message` (`Message_Id`, `Message`, `Date_Added`) VALUES
(1, 'Hope your birthday bestows you with more happiness, love and fun than you ever thought you could take...and then some! You deserve it all. Enjoy your special day!', NULL),
(2, 'May you have such an incredibly special birthday that every day afterward starts and ends with joy, love, laughter and peace of mind.', NULL),
(3, 'Happy birthday. May the next 12 months of the year be the happiest of your life. Hope every day is packed with memories that you''ll treasure evermore.', NULL),
(4, 'Hope your birthday brings you whatever you want. You deserve happiness, love and, most of all, fun on your special day.', NULL),
(5, 'Have a great birthday with all the love, laughter and joy you deserve.', NULL),
(6, 'May this birthday and the coming year bring you good surprises â€” filled with sunshine, smiles and sweethearts.', NULL),
(7, 'Hope you create and enjoy heaps of beautiful birthday memories to cherish your entire life. Happy birthday.', NULL),
(8, 'On your special day, you should only have the good luck that comes with family and friends. Happy birthday.', NULL),
(9, 'Hope your special day fills up your heart and soul with joy, wonder and love.', NULL),
(10, 'I only have the best birthday blessings for you â€” today and forever. Happy birthday.', NULL),
(11, 'Have an amazing birthday. Be sure to celebrate whatever brings you bliss and contentment.', NULL),
(12, 'May your birthday be filled with hours upon hours of joy and love. Happy birthday.', NULL),
(13, 'Happy birthday! May you have the best of luck on your special day, bringing you the joy, peace and wonder you so rightfully deserve. ', NULL),
(14, 'Happy birthday! It''s time for you to have an amazing birthday and savor the joy, love and peace we aim to bring you.', NULL),
(15, 'May every moment of your birthday be the happiest you''ve ever had â€” and may your happiness spill over to every other day of the year. ', NULL),
(16, 'May your life be a series of fortunate events with countless happy birthdays, starting with this one.', NULL),
(17, 'Happy birthday. Letâ€™s light your birthday candles and mark the most special day of the year â€” your birthday.', NULL),
(18, 'Happy birthday. Hope you begin your special day with a gigantic smile on your beautiful face â€” and it only gets bigger and bigger with each hour of your birthday. ', NULL),
(19, 'Here''s to your special day. Let''s make it a truly special celebration. Happy birthday.', NULL),
(20, 'Happy birthday. May all your dreams become what you truly want.', NULL),
(21, 'Happy birthday. May every dream of yours set your life on fire, brightening up today, your special day, and every other day of the year.', NULL),
(22, 'Have an amazing birthday. Light your birthday candles and wish upon a star or all the stars in the sky (you certainly deserve everything coming to you).', NULL),
(23, 'With this birthday, you''re a little older and a lot more wonderful. Have the happiest of special days.', NULL),
(24, 'Every year, you become greater in every way that really matters. Have a great birthday.', NULL),
(25, 'May your special day be packed with all the joy, peace and glory you wish for. Happy birthday.', NULL),
(26, 'Light and blow out each candle on your birthday cake...not because it''s what people do, but to celebrate another special day of your extraordinary life. Happy birthday.', NULL),
(27, 'You''re very special â€” and you should know it. So I will let you how much every second of your special day. Happy birthday.', NULL),
(28, 'You''re a wonderful person who has always deserved only the best of everything, nothing less. Happy birthday.', NULL),
(29, 'There are so many beautiful things I want to say about youâ€¦every day. Today, though, I have only one â€” happy birthday.', NULL),
(30, 'Wishing you a birthday celebration that''s as amazing as you are to everyone you know and love. Happy birthday.', NULL),
(31, 'Your birthday should be a national holiday, so you can celebrate your special day from sunrise to sunset. Happy birthday.', NULL),
(32, 'Another birthday, another year you''ve been blessed with more of everything that makes you an amazing individual. Happy birthday.', NULL),
(33, 'Everyone deserves to have a special day, at least once a year on their birthday. Special people like you deserve to have a special birthday celebration in their honor, every day of the year. Happy birthday.', NULL),
(34, 'You are one of the truest friend I''ve ever had. You''re the best, and the best you shall have on your special day. Happy birthday.', NULL),
(35, 'May your birthday set your life on so much in order and light up your path to inner joy, well-being and love. Happy Birthday', NULL),
(36, 'You may be growing older every year, but you''re the same person â€” perfect as ever. Happy birthday.', NULL),
(37, 'Happy birthday. May you only enjoy the best things that life can offer â€” because you are definitely one of the best.', NULL),
(38, 'Happy Birthday, I''ve always wanted to let you know how precious you are. You are the best. Happy Birthday once more.', NULL),
(39, 'There''s no better best friend than you in my world. Happy birthday.', NULL),
(40, 'Happy birthday. May the start of a new year in your life bring you every bit of happiness, health and prosperity you deserve.', NULL),
(41, 'Happy birthday. Nowâ€™s the time to remember, so let''s celebrate your special day in the most special of ways â€” with joy, with fun, and with love. ', NULL),
(42, 'Wishing you a very happy birthday, not because I have to but because I want to. You''re one of the finest people I know.', NULL),
(43, 'Have a beautifully wonderful birthday, one of the special days someone like you should have.', NULL),
(44, 'Your birthday should be a national holiday, so all the people who know and love you can have a day off to celebrate your arrival into our lives. Happy birthday.', NULL),
(45, 'Another birthday, another year older and, most importantly, another reason to celebrate you all day and all night. ', NULL),
(46, 'Happy birthday. May only the world''s greatest treasures â€” love, joy, adventure and peace â€” be yours, today and every day.', NULL),
(47, 'Sure, with every birthday, you get a little older. But you also get the wisdom to see what''s truly beautiful, truly full of joy, truly yours to celebrate.\r\n\r\n', NULL),
(48, 'From one hopeful dreamer to another, may you have the happiest of birthdays, the kind that wishful thoughts are made of.', NULL),
(49, 'Birthdays come and go so fast, before we even realize that the day we were born is truly a special one. Let''s make your special day especially about you. Let''s celebrate you.', NULL),
(50, 'I''m more than proud to call you my friend â€” I''m grateful, honored, blessed, overjoyed, fortunate and humbled. Happy birthday.', NULL),
(51, 'When God created friends, He made them in your image...the best friend anyone can ever have. Happy birthday', NULL),
(52, 'Take every birthday wish you''ve received today, multiply all the love you found in them by 1,000, then add years of joy, wonder and prosperity to the mix...and it still wouldn''t equal all the love, joy, wonder and prosperity I wish for you.', NULL),
(53, 'Any day we can live our lives to the fullest is a gift. Savor every moment of your special day, because you''ll have to wait another 364 days to feel as special. Happy birthday.', NULL),
(54, 'For your special day, I have only two birthday wishes for you: now and forever. Be happy in the now, so you''ll be happy forever!', NULL),
(55, 'Hope you have a wonderful birthday that lasts all year round!', NULL),
(56, 'Happier birthdays come to dreamers who dare to take action. Like you.', NULL),
(57, 'Happy birthday balloon, cake, candles, ice cream and present day!', NULL),
(58, 'Happy birthday! May joy be your companion everywhere you go.', NULL),
(59, 'Take the time to have a bright, sunshiny, \r\nfun-filled birthday!', NULL),
(60, 'Happy birthday. From the depths of my blissful soul to the peak of my unbridled passion, I wish you the happiest of special days.', NULL),
(61, 'Happy birthday. From the depths of my blissful soul to the peak of my unbridled passion, I wish you the happiest of special days.', NULL),
(62, 'On your special day, look back at all the wonderful moments youâ€™ve shared â€” and look forward to even more amazing ones yet to share. Happy birthday.', NULL),
(63, 'If anyone deserves to experience joy, peace and wonder to the fullest, itâ€™s you. Happy birthday!', NULL),
(64, 'Every day may be the first day of the rest of your life, but your birthday was your very first. Celebrate it as if there were no tomorrows. Happy birthday.', NULL),
(65, 'Happy birthday! May your special day be as warm as the sunlight, as breezy as the wind and as right as rain. ', NULL),
(66, 'Your birthday is the perfect time to stop brooding over the thorns in life and promise yourself the rose garden of your dreams.', NULL),
(67, 'Here''s to a birthday full of life and a life full of happy birthdays!', NULL),
(68, 'Donâ€™t think about how old you are. Think how blessed you are. Think about all the experiences you''ve had in life â€” both good and bad â€” that have brought you this far. Hereâ€™s to life! Happy birthday!', NULL),
(69, 'Happy birthday! Hope this special day is the start of your most special year ever!', NULL),
(70, 'Happy birthday! Today, celebrate the day you were born. Every day, celebrate life.', NULL),
(71, 'Birthdays are nature''s way of telling you that you are getting old, especially when you have to look in the mirror the next morning. Have a happy birthday.', NULL),
(72, 'Jump for joy! It''s your birthday! Have a truly special day. Happy Birthday.', NULL),
(73, 'If the love you take is equal to the love you make, you must be the world''s most loved and loving person. Iâ€™m glad I get to bask in the sunshine of your love. Happy birthday!', NULL),
(74, 'Great things do happen to great people â€” especially on their special day â€” and you''re certainly one of the greatest people I know and love. Happy birthday!', NULL),
(75, 'Happy birthday! For most people, wisdom comes with age. For others, it''s prosperity. For everyone I know, it just means getting older.', NULL),
(76, 'There''s only one thing I like about you: everything. Happy birthday!', NULL),
(77, 'Your birthday doesn''t mean you''re another year older â€” it means you have another year to celebrate. Happy birthday.', NULL),
(78, 'You are a role model for the truly one of a kind. You were born an original! Happy birthday.', NULL),
(79, 'Happy birthday! Hope your special day is as nice as you are and bestows you with twice as much as you wished for!', NULL),
(80, 'Happy birthday. Every year you get closer and closer to who you really are, what you truly want to be. Now that''s really something to wish for.', NULL),
(81, 'Happy birthday. May your heart beat true with the joy, love and laughter you bring to everyone around you.', NULL),
(82, 'We were all made in God''s image. When you smile, I can see God in your eyes, the window to your beautiful soul. Happy birthday.\r\n', NULL),
(83, 'May God bless you all your days, and doubly so on your special day. Happy birthday!\r\n\r\n\r\n', NULL),
(84, 'Happy birthday. May God keep you young at heart and beautiful of mind.\r\n\r\n', NULL),
(85, 'Happy birthday. It gives me great pleasure to see that God has blessed you with another year of life. May you be blessed with many more.\r\n\r\n', NULL),
(86, 'Each birthday is a gift of love, joy and wonder from God. Celebrate to your heart''s content and your soul''s fulfilled. Happy birthday.\r\n\r\n', NULL),
(87, 'Happy birthday. May God bless you with years upon years of joy, health, wonder and faith!\r\n\r\n', NULL),
(88, 'I hope your special day will bring you lots of happiness, love and fun. You deserve them a lot.  Happy Birthday.\r\n', NULL),
(89, 'Have a wonderful birthday. I wish your every day to be filled with lots of love, laughter, happiness and the warmth of sunshine.\r\n', NULL),
(90, 'May your coming year surprise you with the happiness of smiles, the feeling of love and so on. I hope you will find plenty of sweet memories to cherish forever. Happy birthday.\r\n', NULL),
(91, 'Itâ€™s your birthday. Now youâ€™ve more grown up. Every year youâ€™re becoming more perfect.\r\n', NULL),
(92, 'On your special day, I wish you good luck. I hope this wonderful day will fill up your heart with joy and blessings. Have a fantastic birthday, celebrate the happiness on every day of your life. Happy Birthday!!\r\n', NULL),
(93, 'May this birthday be filled with lots of happy hours and also your life with many happy birthdays, that are yet to come. Happy birthday.\r\n', NULL),
(94, 'Letâ€™s light the candles and celebrate this special day of your life. Happy birthday.\r\n', NULL),
(95, 'You are very special and thatâ€™s why you need to float with lots of smiles on your lovely face. Happy birthday.\r\n', NULL),
(96, 'Special day, special person and special celebration. May all your dreams and desires come true in this year. Happy birthday.\r\n', NULL),
(97, 'You are a person who always deserves the best and obviously nothing less. Wish your birthday celebration will be as fantastic as you are. Happy birthday.\r\n', NULL),
(98, 'Another birthday, so you are growing older gradually. But I find no change in you. You look perfect like before. Happy birthday.\r\n', NULL),
(99, 'Happy birthday. May all the best things of the world happen in your life because you are definitely one of the best people too.\r\n', NULL),
(100, 'Wishing happy birthday to one of the best persons Iâ€™ve ever met in this world.\r\n', NULL),
(101, 'I feel proud when I call you my friend. I want to feel this today and every day.', NULL),
(102, 'May all the best blessings rain upon you today and always. Happy birthday.', NULL),
(103, 'Your birthday is more special to me than you, because on this day, one of the most precious friend of my entire life came into being. Happy Birthday.', NULL),
(104, 'A birthday cake is always good, but to me a friend like you is undoubtedly great. Happy Birthday.', NULL),
(105, 'My warmest wishes for the most wonderful friend I have. Happy Birthday.', NULL),
(106, 'As you go through each year, remember to count your blessings, not your age. Count your amazing experiences, not your mistakes. Happy Birthday to an awesome person!', NULL),
(107, 'On your birthday, look to the future and forget your past- the best is still to come. Happy birthday, friend.', NULL),
(108, 'For you on your birthday, I wish you a lifetime of happiness, no worries, and a boat load of big dreams coming true. Happy Birthday.', NULL),
(109, 'A birthday is one of the most important days of the year- may yours be filled with the light of living and the brightness of laughter. Happy Birthday.', NULL),
(110, 'Words cannot express how happy I am to say â€˜happy birthdayâ€™ to you another year of your life. You are so special to me.', NULL),
(111, 'Roses may be red and violets blue, but you put all the colors in the rainbow to shame. Happy birthday to the brightest, best person I know!', NULL),
(112, 'To a dear friend- thanks for always being there for me through the thick and the thin. Youâ€™re truly the best. Happy birthday to you!', NULL),
(113, 'I know your birthday is a special day with or without me, but I have to say that you are the best friend Iâ€™ve ever had! Happy Birthday.', NULL),
(114, 'A birthday is a time for celebration- itâ€™s a time to celebrate the life of someone special. Hereâ€™s to you getting love, joy, and happiness on your special day. Happy Birthday.', NULL),
(115, 'May this year be a breakthrough year for you! I hope that all your stars keep shining and your biggest dreams come true. Congrats on another great year. Happy Birthday.', NULL),
(116, 'Every time you blow out a candle it marks another year you have contributed to the world with your humbling presence. Thanks for that and happy birthday!', NULL),
(117, 'Another year older means another year wiser, and hotter. Glad you were born to share your wisdom. Happy birthday.', NULL),
(118, 'I guess you thought I forgot about today. How could I ever forget a day as special as a good friendâ€™s birthday! I want to send you a Happy Birthday and remind you of how important your friendship is to me.', NULL),
(119, 'I have been looking for a decent gift to give you on this special day of yours but to no avail. I guess this is simply because there is no way on earth I could ever get a gift as special as you. Happy Birthday.', NULL),
(120, 'No matter how old you get, always remember to stay young at heart and make every year count. Happy Birthday to you!', NULL),
(121, 'No matter how old you get, always remember to stay young at heart and make every year count. Happy Birthday to you!', NULL),
(122, 'May your heart always guide you to find the truest form of happiness- because you deserve it all. Happy Birthday.', NULL),
(123, 'May the brightest star always light up your life path. Happy Birthday.', NULL),
(124, 'Life is a great journey, so make sure you enjoy every mile. Happy Birthday!', NULL),
(125, 'Our lives may have changed, but our friendship has stayed strong. Happy Birthday! May all your heartâ€™s desires come true on your special day!', NULL),
(126, 'This is your special day and I hope you see this day as more than just a reminder that you are getting older, but as an amazing opportunity for you to gather with great friends, have fun and relive all the amazing memories of the previous years! Happy birthday to you, dear!', NULL),
(127, 'Dance. Party. Celebrate. Sing. Shake it. Why not? Itâ€™s your birthday!', NULL),
(128, 'Hoping you have a wonderful birthday filled with love and laughter!', NULL),
(129, 'Celebrate your birthday. Celebrate today. But most of all, be happy every day! Happy Birthday.', NULL),
(130, 'Birthday brings more blessing. I wish you all the joy and happiness your heart can accommodate. Happy Birthday.', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `birthday_message`
--
ALTER TABLE `birthday_message`
  ADD PRIMARY KEY (`Message_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `birthday_message`
--
ALTER TABLE `birthday_message`
  MODIFY `Message_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
